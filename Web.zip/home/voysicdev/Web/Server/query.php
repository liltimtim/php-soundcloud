<?php
/*
 * Handle client queries and client updates to database
 * 
 * 
 */
error_reporting(E_ALL);
if (!ini_get('display_errors')) {
    ini_set('display_errors', 1);
}
// init_set('display_errors', 1);
error_reporting(E_ALL);
// init_set('display_errors', 1);
$username = 'root';
$password = "Timoshii1!";

function handleRequest(){
    if ($_POST['query_type'] == "update_song"){
        // echo "successfully got your data";
        $responseArray = [];
        $responseArray['response'] = $_POST['payload'];
        // respondToClient($responseArray);
        updateDatabase($_POST['payload']);
    }
    if ($_POST['query_type'] == "whos_online"){
        //client wants to know who is online if anyone is
        // $online = whosOnline();
        respondToClient(whosOnline());
    }
    if ($_POST['query_type'] == "get_token"){
        //client wants it's access token.
        $token = get_token($_POST['code']);
        $responseArray['response'] = $token;
        respondToClient($responseArray);
    }
}

/*
 * Handle updating database.  Search for user if not found add user.
 * @input: user_id
 */
function updateDatabase($payload){
    //first need to see if user already exists, if so update that record.
    //else create a new record for the 
    // respondToClient($payload);
    global $username, $password;
    try{
        $conn = new PDO('mysql:host=localhost;dbname=users', $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stmt = $conn->prepare('SELECT * FROM online_users WHERE id = :userID');
        
        //DONT FORGET TO EXECUTE THE STATEMENT
        $stmt->execute(array('userID' => $payload['id']));
        $result = $stmt->fetchAll();
        if(count($result) == 0){
            //nothing found in the database so create the user
            $stmt = $conn->prepare('INSERT INTO online_users VALUES(:userID, :username, :currentSong, :startTime, :playStatus, :payloadData)');
            $stmt->execute(array(
                'userID' => $payload['id'],
                'username' => $payload['username'],
                'currentSong' => $payload['currentSong'], 
                'startTime' => round(microtime(true) * 1000), 
                'playStatus' => 1, 
                'payloadData' => json_encode($payload)));
            $responseArray = [];
            $responseArray['response'] = "User " . $payload['id'] . " wasn't found in db, added user";
            respondToClient($responseArray);
        }else{
            //user was found update the new song
            try{
                $stmt = $conn->prepare('UPDATE online_users SET current_song = :currentSong WHERE id = :id');
                $stmt->execute(array(
                    ':currentSong'  => $payload['currentSong'],
                    ':id'           => $payload['id']));
            }catch(PDOException $e){
                $responseArray = [];
                $responseArray['response'] = $e->getMessage();
                respondToClient($responseArray);
            }
            respondToClient($result);
        }
    }catch(PDOException $e){
        // echo 'ERROR: ' . $e->getMessage();
        $responseArray = [];
        $responseArray['response'] = $e->getMessage();
        respondToClient($responseArray);
    }
}

function get_token($which_token){
    global $username, $password;
    // $output = "NULL";
    try{
        $conn = new PDO('mysql:host=localhost;dbname=access_tokens', $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stmt = $conn->prepare('SELECT * FROM tokens WHERE client_code = :token');
        $stmt->execute(array(':token' => $which_token));
        $result = $stmt->fetchAll();
        $online_tokens = [$result];
        return $result[0][1]; //comes as a key pair value first value is the key or client_id the pair is the access_code
    }
    catch(PDOException $e){
        $responseArray = [];
        $responseArray['response'] = $e->getMessage();
        respondToClient($responseArray);
        return "not null you ass";
    }
}

function whosOnline(){
    global $username, $password;
    try{
        $conn = new PDO('mysql:host=localhost;dbname=users', $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stmt = $conn->prepare('SELECT  * FROM online_users WHERE 1');
        $stmt->execute();
        $result = $stmt->fetchAll();
        
        //people will be online if array is greater than 0, no one online if == 0
        if(count($result) > 0){
            //someones online awesome!
            $onlineUsersArray = [];
            foreach($result as $row){
                array_push($onlineUsersArray, $row);
            }
            return $onlineUsersArray;
            // respondToClient($onlineUsersArray);
        }else{
            //no one is online boooo!
            $responseArray = [];
            $responseArray['online'] = "None";
            // respondToClient($responseArray);
            return $responseArray;
            
        }
    }catch(PDOException $e){
        // error executing statement
        $responseArray = [];
        $responseArray['response'] = $e->getMessage();
        respondToClient($reponseArray);
    }
}

function respondToClient($message){
    $encodedJSON = json_encode($message);
    echo $encodedJSON;
}
handleRequest();
?>