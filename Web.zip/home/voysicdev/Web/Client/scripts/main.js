var CLIENT_ID="22a2d718a1f4eea671abea5d1d9aa55f";
var BASE_URL = "http://api.soundcloud.com/";
var REDIRECT_URI = 'http://www.voysicdev.kd.io/callback.html';
var SERVER_QUERY = 'http://www.voysicdev.kd.io/Server/query.php';
var user_id = "";
var username = "";
var me = "";
// var user_id = 'http://www.voysicdev.kd.io/callback.html';
$(document).ready(function(){
   //authenticate user
    console.log("Authenticating user");
    SC.initialize({
        client_id: CLIENT_ID,
        redirect_uri: REDIRECT_URI,
    });
    SC.connect(function(){
        //Connected!
        console.log("Initiating popup window for authentication");
        SC.get('/me', function(data){
            me = data;
            console.log(me);
            user_id = me.id;
            username = me.username;
            console.log("User ID: " + me.id);
            console.log("User Username: " + me.username);
            
            //Send ME data to Geekin Server
            //TODO
            
            //ask Geekin Server who is online.
            whosOnline();
        });
        listOnlineUsers();
    });

    
    //event listeners
    $("#online_users").click(function(selection){
        console.log(selection);
    });
    
});

/***************************************************************
 * list users that are online
 **************************************************************/
function listOnlineUsers(){
    var selector = "#online_list";
    SC.get('/me/followings', function(me){
        // console.log(me);
        for(var i = 0; i < me.length; i++){
            // console.log(me[i]);
            appendToList(selector, me[i].id, me[i].username);
        }
    });
}

/**************************************************************
 * Append a list of online users to the main div in the app
 **************************************************************/
function appendList(userId, userName){
    var item = document.createElement("li")
    item.setAttribute("value",userId);
    item.innerHTML = userName;
    $("#online_list").append(item)
}

/**************************************************************
 * A general function to append children to a <ul>
 * @input: [DOM Selector], [attribute value], [innerHTML]
 * 
 * example input:
 * [dom selector] = #online_list
 * [attribute value] = 2341234 (this value is from SC)
 * [innerHTML] = "Some Value" (value that will appear as text)
 **************************************************************/
function appendToList(selector, value, htmlValue){
    var item = document.createElement("li");
    item.setAttribute("value", value);
    item.setAttribute("onclick", "getSongs(this.value)");
    item.innerHTML = htmlValue;
    $(selector).append(item);
    // $(selector).append(tempButtonAdd(value));
}
function appendToListSongs(selector, value, htmlValue, onclickValue){
    var item = document.createElement("li");
    // console.log(htmlValue);
    item.setAttribute("value", value);
    item.setAttribute("onclick", onclickValue);
    item.innerHTML = htmlValue;
    $(selector).append(item);
    // $(selector).append(tempButtonAdd(value));
}
function appendToListOnlineUsers(selector, value, htmlValue, onclickValue){
    console.log("Appending to Online Users");
    console.log("Song ID: " + value + " User: " + htmlValue);
    var item = document.createElement("li");
    item.setAttribute("value", value);
    item.setAttribute("onclick", onclickValue);
    item.innerHTML = htmlValue;
    $(selector).append(item);
    
}

//TEMP FUNCTION
function tempButtonAdd(userId){
    var button = document.createElement("button");
    button.setAttribute("onclick", getSongs());
    button.innerHTML = userId;
    return button;
}

/**************************************************************
 * Refresh the list of 'online' users
 **************************************************************/
function refreshOnlineUsers(){
    console.log("Refreshing Online Users");
    var selector = "#online_list";
    $(selector).children().remove();
    SC.get('/me/followings', function(me){
       for(var i = 0; i < me.length; i++){
        //   console.log(me[i]);
           appendToList(selector, me[i].id, me[i].username);
       } 
    });
}

/**************************************************************
 * Get selected 'users' sounds
 * @input [user id]
 **************************************************************/
function getSongs(value){
    var query = "/users/"+value+"/tracks";
    var selector = "#available_songs_li";
    var onclickFunction = "startStream(this.value)";
    
    //remove any songs currently in list
    $(selector).children().remove();
    
    SC.get(query, function(songs){
        console.log(songs);
        for(var i = 0; i < songs.length; i++){
            appendToListSongs(selector, songs[i].id, songs[i].title, onclickFunction);
        }
    })
}

/**************************************************************
 * Initialize a stream from the selected song
 * and update database with current song
 * 
 * There are 3 types of play status: 
 * 0 - stopped
 * 1 - playing
 * 2 - paused
 * 
 * @input [stream url provided by soundcloud]
 **************************************************************/
function startStream(stream_url){
    console.log(stream_url);
    var query = "/tracks/"+stream_url;
    var status = 0; //initial song status is 0 - not playing

    SC.stream(query, function(sound){
        sound.play();
        status = 1; //set play status to 1
        updateCurrentSong(user_id, username, stream_url, status);
        $("#play_btn").click(function(){
            console.log("Playing song");
            sound.play(); //start playing sound
            updateCurrentSong(user_id, username, stream_url, status);
        });
        $("#pause_btn").click(function(){
            console.log("Pausing playback");
            sound.pause(); //pause current song
            //TODO
            //update current play position and status
        });
        $("#stop_btn").click(function(){
            console.log("Stopping playback");
            sound.stop();
            //TODO
            //update play status and stop position
        });
        $("#reset_btn").click(function(){
           console.log("Resetting sound");
           sound.destruct();
           //TODO
           //remove user from online users in db
        });
    });
}
/**************************************************************
 * Sends song data to server to update currently playing sound
 * @input: user_id, user_name, streamUrl, status
 **************************************************************/
function updateCurrentSong(uID, uName, streamUrl, playStatus){
    me.currentSong = streamUrl;
    console.log("updating server with current song");
    console.log(me);
    var serverQuery = $.post(SERVER_QUERY, {query_type: "update_song", payload: me}, function(response){
        console.log("Query sent to server successfully");
        console.log(response);
        var responseObj = jQuery.parseJSON(response);
        console.log(responseObj);
    })
    .fail(function(){
        console.log("Error while uploading");
    })
}
/**************************************************************
 * Find out who is online and is playing music from the Geekin 
 * server.
 * 
 * If none online, "None" will be the response from server else
 * an array will be returned.
 * 
 * NOTE: 'value' in the HTML will store the song ID the user is
 * listening to and the innerHTML will be the username
 **************************************************************/
function whosOnline(){
    console.log("retrieving online users");
    var selector = "#online_people";
    var onclickValue = "startStream(this.value)";
    $(selector).children().remove();
    var serverQuery = $.post(SERVER_QUERY, {query_type: "whos_online"}, function(response){
        console.log("Whos online query sent with success");
        console.log(response);
        var responseObj = jQuery.parseJSON(response);
        console.log(responseObj);
        for(var i = 0; i < responseObj.length; i++){
            appendToListOnlineUsers(selector, responseObj[i].current_song, responseObj[i].username, onclickValue);
        }
    })
}