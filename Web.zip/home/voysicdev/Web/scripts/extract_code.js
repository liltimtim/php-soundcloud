function extract_url(){
  var searchString = window.location.search.substring(1), params = searchString.split("&"), hash = {};
  var user_code = searchString.split('=');
  alert(user_code[1]);
//   alert("test");
}

extract_url();