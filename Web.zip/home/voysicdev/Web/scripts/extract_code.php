<?php
error_reporting(E_ALL);
if (!ini_get('display_errors')) {
    ini_set('display_errors', 1);
}
// init_set('display_errors', 1);
$username = 'root';
$password = "Timoshii1!";

require_once 'Soundcloud.php';
$CLIENT_ID = '22a2d718a1f4eea671abea5d1d9aa55f';
$CLIENT_SECRET = '3fefc67a2501f6796f522e11ad9f77c4';
$REDIRECT_URL = 'http://voysicdev.kd.io/scripts/extract_code.php';

// create client object with app credentials
$soundcloud = new Services_Soundcloud($CLIENT_ID, $CLIENT_SECRET, $REDIRECT_URL);
echo '<a href="' . $soundcloud->getAuthorizeUrl() . '">Connect with SoundCloud</a><br />';

// exchange authorization code for access token
$accessToken = $soundcloud->accessToken($_GET['code']);
$soundcloud->setAccessToken($accessToken["access_token"]);
// storeToken($code, $token);
echo "tokens";
echo $accessToken['access_token'];
storeToken($_GET['code'], $accessToken['access_token']);

/*
 * Stores the clients code and access token together in the DB
 * 
 * @input: code, token code
 */
function storeToken($client_code, $access_token){
    global $username, $password;
    try{
        $conn = new PDO('mysql:host=localhost;dbname=access_tokens', $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stmt = $conn->prepare('INSERT INTO tokens VALUES(:client_code, :client_access_token)');
        $stmt->execute(array(':client_code' => $client_code,
                             ':client_access_token' => $access_token));
    }
    catch(PDOException $e){
        $responseArray = [];
        $responseArray['response'] = $e->getMessage();
        respondToClient($responseArray);
    }
}
?>