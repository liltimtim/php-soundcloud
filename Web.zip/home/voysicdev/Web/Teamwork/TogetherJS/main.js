// get the canvas element and its context
var canvas = document.querySelector('#sketch');
var context = canvas.getContext('2d');

var sketchContainer = document.querySelector('#sketchContainer');
var sketchStyle = getComputedStyle(sketchContainer);
canvas.width = parseInt(sketchStyle.getPropertyValue('width'), 10);
canvas.height = parseInt(sketchStyle.getPropertyValue('height'), 10);

var lastMouse = {
    x: 0,
    y: 0
};

// brush settings
context.lineWidth = 2;
context.lineJoin = 'round';
context.lineCap = 'round';
context.strokeStyle = '#000';

// attach the mousedown, mousemove, mouseup event listeners.
canvas.addEventListener('mousedown', function (e) {
    lastMouse = {
        x: e.pageX - this.offsetLeft,
        y: e.pageY - this.offsetTop
    };
    canvas.addEventListener('mousemove', move, false);
}, false);

canvas.addEventListener('mouseup', function () {
    canvas.removeEventListener('mousemove', move, false);
}, false);

function move(e) {
    var mouse = {
        x: e.pageX - this.offsetLeft,
        y: e.pageY - this.offsetTop
    };
    draw(lastMouse, mouse);
    lastMouse = mouse;
}

function draw(start, end, remote) {
    context.beginPath();
    context.moveTo(start.x, start.y);
    context.lineTo(end.x, end.y);
    context.closePath();
    context.stroke();
    if ((!remote) && TogetherJS.running) {
        TogetherJS.send({
            type: "draw",
            start: start,
            end: end
        });
    }
}

TogetherJS.hub.on("draw", function (msg) {
    draw(msg.start, msg.end, true);
});

TogetherJS.hub.on("togetherjs.hello", function () {
    var image = canvas.toDataURL("image/png");
    TogetherJS.send({
        type: "init",
        image: image
    });
});

TogetherJS.hub.on("init", function (msg) {
    var image = new Image();
    image.src = msg.image;
    context.drawImage(image, 0, 0);
});
