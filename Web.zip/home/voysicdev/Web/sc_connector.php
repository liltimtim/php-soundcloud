<?php
/************************************************************************
 * Example of how server side can connect to a user profile and authenticate
 * itself as the user once approved. 
 ***********************************************************************/

echo("complete");
require_once 'Services/Soundcloud.php';
ini_set('display_errors',1); 
error_reporting(E_ALL);
$CLIENT_ID = '22a2d718a1f4eea671abea5d1d9aa55f';
$CLIENT_SECRET = '3fefc67a2501f6796f522e11ad9f77c4';
$REDIRECT_URL = 'http://voysicdev.kd.io/scripts/extract_code.php';

//client id, client secret, redirect url (authentication token)
$client = new Services_Soundcloud($CLIENT_ID,$CLIENT_SECRET,$REDIRECT_URL);
    
//redirect user
header("Location: " . $client->getAuthorizeUrl(array('scope' => 'non-expiring')));



?>
